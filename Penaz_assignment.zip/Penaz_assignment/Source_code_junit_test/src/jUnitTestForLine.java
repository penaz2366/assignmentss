import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Scanner;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class jUnitTestForLine {
	LineCalculator linecal;
	
	public void testcareLine()throws Exception {
	
		
	}
	
	public void isReturnValue()throws Exception {
		//LineCalculator linecal = new LineCalculator();
		
		
	}

	private void assertTrue(int returnedLine) {
		// TODO Auto-generated method stub
		System.out.println("slope : -> "+returnedLine);
		
	}
	
	@BeforeEach
	void setUp() throws Exception {
		linecal = new LineCalculator();
		
	}

	@Test
	void test() {
		//fail("Not yet implemented");
		System.out.println("Please enter the four co-ordinate :");
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter x1 :");
		int x1 = sc.nextInt();
		System.out.println("Please enter x2 :");
		int x2 = sc.nextInt();
		System.out.println("Please enter y1 :");
		int y1 = sc.nextInt();
		System.out.println("Please enter y2 :");
		int y2 = sc.nextInt();
		
		assertTrue(linecal.isReturnedLine(x1,x2,y1,y2));
		assertTrue2(linecal.isReturnedDistance(x1,x2,y1,y2));
		assertTrue1(linecal.isReturnedEquation(x1,x2,y1,y2));
		//assertNotNull(linecal);
	}

	private void assertTrue2(int returnedDistance) {
		// TODO Auto-generated method stub
		System.out.println("Distance : -> "+returnedDistance);
		
	}

	private void assertTrue1(String returnedEquation) {
		// TODO Auto-generated method stub
		System.out.println("Equation : -> "+returnedEquation);
		
		
	}

}
