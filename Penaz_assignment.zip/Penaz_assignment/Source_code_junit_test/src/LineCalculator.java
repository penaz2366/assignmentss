import java.util.Scanner;
import java.util.function.BooleanSupplier;

public class LineCalculator {

	public int isReturnedLine(int x1, int x2, int y1, int y2) {
		// TODO Auto-generated method stub
		
		int slope = (y2-y1) / (x2-x1);
		return slope;
	}

	public int isReturnedDistance(int x1, int x2, int y1, int y2) {
		// TODO Auto-generated method stub
		
		double distance = Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y2));
		return (int) distance;
	}

	public String isReturnedEquation(int x1, int x2, int y1, int y2) {
		// TODO Auto-generated method stub
		int slope = (y2-y1) / (x2-x1);
		String str = (slope+"x-"+(slope*x1)+"="+"y-"+y1);
		return str;
	}
	
	

	
}
